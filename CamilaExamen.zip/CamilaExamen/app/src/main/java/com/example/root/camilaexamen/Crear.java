package com.example.root.camilaexamen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import com.example.root.camilaexamen.models.Persona;

public class Crear extends AppCompatActivity implements View.OnClickListener {
    Persona persona1;

    EditText cedula, nombre , recinto, junta, direccion, provincia, canton ,parroquia,zona;
    Button crear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear);

        crear=(Button)findViewById(R.id.botonCrear);
        crear.setOnClickListener(this);

        cedula=(EditText)findViewById(R.id.txtCedula);
        nombre=(EditText)findViewById(R.id.txtNombre);
        recinto=(EditText)findViewById(R.id.txtRecinto);
        junta=(EditText)findViewById(R.id.txtJunta);
        direccion=(EditText)findViewById(R.id.txtDireccion);
        provincia=(EditText)findViewById(R.id.txtProvincia);
        canton=(EditText)findViewById(R.id.txtCanton);
        parroquia=(EditText)findViewById(R.id.txtParroquia);
        zona=(EditText)findViewById(R.id.txtZona);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.botonCrear:

                persona1=new Persona();

                    persona1.setCedula(String.valueOf(cedula.getText().toString()));
                    persona1.setNombre(String.valueOf(nombre.getText().toString()));
                    persona1.setRecinto(String.valueOf(recinto.getText().toString()));

                    persona1.setJunta(String.valueOf(junta.getText().toString()));
                    persona1.setDireccion(String.valueOf(direccion.getText().toString()));
                    persona1.setProvincia(String.valueOf(provincia.getText().toString()));
                    persona1.setCanton(String.valueOf(canton.getText().toString()));
                    persona1.setParroquia(String.valueOf(parroquia.getText().toString()));
                    persona1.setZona(String.valueOf(zona.getText().toString()));

                persona1.save();

                nombre.setText("");
                cedula.setText("");
                recinto.setText("");
                junta.setText("");
                direccion.setText("");
                provincia.setText("");
                canton.setText("");
                parroquia.setText("");
                zona.setText("");


                break;
        }
    }
}
