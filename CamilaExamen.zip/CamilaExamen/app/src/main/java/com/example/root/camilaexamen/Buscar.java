package com.example.root.camilaexamen;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.activeandroid.query.Select;
import com.example.root.camilaexamen.models.Persona;

import java.util.List;

public class Buscar extends AppCompatActivity  implements View.OnClickListener {

    EditText cedulaB;
    TextView nombre, recinto, junta, direccion, provincia, canton, parroquia, zona;
    Button resultado;
    TextView vistaBD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar);

        cedulaB=(EditText)findViewById(R.id.txtCedulaBuscar);

        nombre=(TextView)findViewById(R.id.lblnombre);
        recinto=(TextView)findViewById(R.id.lblrecinto);
        junta=(TextView)findViewById(R.id.lbljunta);
        direccion=(TextView)findViewById(R.id.lbldireccion);
        provincia=(TextView)findViewById(R.id.lblprovincia);
        canton=(TextView)findViewById(R.id.lblcanton);
        parroquia=(TextView)findViewById(R.id.lblparroquia);
        zona=(TextView)findViewById(R.id.lblzona);
        resultado=(Button)findViewById(R.id.botonBuscar) ;
        resultado.setOnClickListener(this);
        vistaBD=(TextView)findViewById(R.id.Resultado);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.botonBuscar:



                List<Persona> lista = new Select().from(Persona.class).where("cedula=?",
                        cedulaB.getText().toString()).execute();


                String c="";
                for(Persona g:lista){
                    c+="Cedula: "+g.getCedula()+",";
                    c+="Nombre: "+g.getNombre()+",";
                    c+="Junta: "+g.getJunta()+",";
                    c+="Direccion: "+g.getDireccion()+",";
                    c+="Provincia: "+g.getProvincia()+",";
                    c+="Canton: "+g.getCanton()+",";
                    c+="Parroquia: "+g.getParroquia()+",";
                    c+="Zona: "+g.getZona()+"\n";

                    nombre.setText(String.valueOf(g.getNombre()));
                    direccion.setText(String.valueOf(g.getDireccion()));
                    provincia.setText(String.valueOf(g.getProvincia()));
                    canton.setText(String.valueOf(g.getCanton()));
                    parroquia.setText(String.valueOf(g.getParroquia()));
                    zona.setText(String.valueOf(g.getZona()));
                    vistaBD.setText(c);


                }

                break;
        }

    }
}
