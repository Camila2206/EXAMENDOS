package com.example.root.camilaexamen;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.activeandroid.query.Select;
import com.example.root.camilaexamen.models.Persona;

import java.util.List;

public class principal extends AppCompatActivity implements View.OnClickListener {

    Button guardar, buscar, lista;
    TextView vistaBD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        guardar=(Button)findViewById(R.id.btnIr);
        guardar.setOnClickListener(this);
        buscar=(Button)findViewById(R.id.btnBuscar);
        buscar.setOnClickListener(this);

        lista=(Button)findViewById(R.id.btnLista);
        lista.setOnClickListener(this);

        vistaBD=(TextView)findViewById(R.id.lblResultadoBase);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btnIr:
                Intent intent= new Intent(principal.this, Crear.class);
                startActivity(intent);
                break;
            case R.id.btnBuscar:
                Intent intent2= new Intent(principal.this, Buscar.class);
                startActivity(intent2);
                break;
            case R.id.btnLista:
                List<Persona> list = new Select().from(Persona.class).execute();
                String s="";
                for (Persona f:list){
                    s+="Cedula:"+f.getCedula()+",  ";
                    s+="Nombre:"+f.getNombre()+",  ";
                    s+="Junta: "+f.getJunta()+",  "+"\n ";
                }

                vistaBD.setText(s);
                break;

        }
    }
}
